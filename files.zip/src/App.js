import React from 'react';
import './styles.css';

const projects = [
  {
    name: 'Transify',
    description: 'A Translation Website which I already made.',
  },
  {
    name: 'STWForALL',
    description: 'A Minecraft Server and other Minecraft Projects (the future of Minecraft).',
  },
  {
    name: 'Re-Anki',
    description: 'Making Anki what it used to be.',
  }
];

const App = () => {
  return (
    <div className="container">
      <header>
        <h1>I\'am Best</h1>
      </header>
      <main>
        <section>
          <h2>Our Projects</h2>
          <div className="projects">
            {projects.map((project, index) => (
              <div key={index} className="project">
                <h3>{project.name}</h3>
                <p>{project.description}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

export default App;